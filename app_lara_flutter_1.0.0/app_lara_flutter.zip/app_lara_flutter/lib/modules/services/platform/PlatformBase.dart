
class PlatformBase {
  String baseUrl;

  PlatformBase();

}