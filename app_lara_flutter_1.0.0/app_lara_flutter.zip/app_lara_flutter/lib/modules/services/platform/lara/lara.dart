import 'package:getgolo/modules/services/platform/PlatformBase.dart';

class Lara extends PlatformBase {
  static const String baseUrlImage = "https://lara.getgolo.com/uploads/";
  Lara(): super(){
    baseUrl = "https://lara.getgolo.com/api/";
  }
  
}