

class CityBloc {

}